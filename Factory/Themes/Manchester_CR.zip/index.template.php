<?php
/**
 * Simple Machines Forum (SMF)
 *
 * @package SMF
 * @author Simple Machines
 * @copyright 2011 Simple Machines
 * @license http://www.simplemachines.org/about/smf/license.php BSD
 *
 * @version 2.0
 */

/*	This template is, perhaps, the most important template in the theme. It
	contains the main template layer that displays the header and footer of
	the forum, namely with main_above and main_below. It also contains the
	menu sub template, which appropriately displays the menu; the init sub
	template, which is there to set the theme up; (init can be missing.) and
	the linktree sub template, which sorts out the link tree.

	The init sub template should load any data and set any hardcoded options.

	The main_above sub template is what is shown above the main content, and
	should contain anything that should be shown up there.

	The main_below sub template, conversely, is shown after the main content.
	It should probably contain the copyright statement and some other things.

	The linktree sub template should display the link tree, using the data
	in the $context['linktree'] variable.

	The menu sub template should display all the relevant buttons the user
	wants and or needs.

	For more information on the templating system, please see the site at:
	http://www.simplemachines.org/
*/

// Initialize the template... mainly little settings.
function template_init()
{
	global $context, $settings, $options, $txt;

	/* Use images from default theme when using templates from the default theme?
		if this is 'always', images from the default theme will be used.
		if this is 'defaults', images from the default theme will only be used with default templates.
		if this is 'never' or isn't set at all, images from the default theme will not be used. */
	$settings['use_default_images'] = 'never';

	/* What document type definition is being used? (for font size and other issues.)
		'xhtml' for an XHTML 1.0 document type definition.
		'html' for an HTML 4.01 document type definition. */
	$settings['doctype'] = 'xhtml';

	/* The version this template/theme is for.
		This should probably be the version of SMF it was created for. */
	$settings['theme_version'] = '2.0';

	/* Set a setting that tells the theme that it can render the tabs. */
	$settings['use_tabs'] = true;

	/* Use plain buttons - as opposed to text buttons? */
	$settings['use_buttons'] = true;

	/* Show sticky and lock status separate from topic icons? */
	$settings['separate_sticky_lock'] = true;

	/* Does this theme use the strict doctype? */
	$settings['strict_doctype'] = false;

	/* Does this theme use post previews on the message index? */
	$settings['message_index_preview'] = false;

	/* Set the following variable to true if this theme requires the optional theme strings file to be loaded. */
	$settings['require_theme_strings'] = false;
}

// The main sub template above the content.
function template_html_above()
{
	global $context, $settings, $options, $scripturl, $txt, $modSettings;

	// Show right to left and the character set for ease of translating.
	echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"', $context['right_to_left'] ? ' dir="rtl"' : '', '>
<head>';

	// The ?fin20 part of this link is just here to make sure browsers don't cache it wrongly.
	echo '
	<link rel="stylesheet" type="text/css" href="', $settings['theme_url'], '/css/index', $context['theme_variant'], '.css?fin20" />';

	// Some browsers need an extra stylesheet due to bugs/compatibility issues.
	foreach (array('ie7', 'ie6', 'webkit') as $cssfix)
		if ($context['browser']['is_' . $cssfix])
			echo '
	<link rel="stylesheet" type="text/css" href="', $settings['default_theme_url'], '/css/', $cssfix, '.css" />';

	// RTL languages require an additional stylesheet.
	if ($context['right_to_left'])
		echo '
	<link rel="stylesheet" type="text/css" href="', $settings['theme_url'], '/css/rtl.css" />';

	// Here comes the JavaScript bits!
	echo '
	<script type="text/javascript" src="', $settings['default_theme_url'], '/scripts/script.js?fin20"></script>
	<script type="text/javascript" src="', $settings['theme_url'], '/scripts/theme.js?fin20"></script>
	<script type="text/javascript"><!-- // --><![CDATA[
		var smf_theme_url = "', $settings['theme_url'], '";
		var smf_default_theme_url = "', $settings['default_theme_url'], '";
		var smf_images_url = "', $settings['images_url'], '";
		var smf_scripturl = "', $scripturl, '";
		var smf_iso_case_folding = ', $context['server']['iso_case_folding'] ? 'true' : 'false', ';
		var smf_charset = "', $context['character_set'], '";', $context['show_pm_popup'] ? '
		var fPmPopup = function ()
		{
			if (confirm("' . $txt['show_personal_messages'] . '"))
				window.open(smf_prepareScriptUrl(smf_scripturl) + "action=pm");
		}
		addLoadEvent(fPmPopup);' : '', '
		var ajax_notification_text = "', $txt['ajax_in_progress'], '";
		var ajax_notification_cancel_text = "', $txt['modify_cancel'], '";
	// ]]></script>';

	echo '
	<meta http-equiv="Content-Type" content="text/html; charset=', $context['character_set'], '" />
	<meta name="description" content="', $context['page_title_html_safe'], '" />', !empty($context['meta_keywords']) ? '
	<meta name="keywords" content="' . $context['meta_keywords'] . '" />' : '', '
	<title>', $context['page_title_html_safe'], '</title>';

	// Please don't index these Mr Robot.
	if (!empty($context['robot_no_index']))
		echo '
	<meta name="robots" content="noindex" />';

	// Present a canonical url for search engines to prevent duplicate content in their indices.
	if (!empty($context['canonical_url']))
		echo '
	<link rel="canonical" href="', $context['canonical_url'], '" />';

	// Show all the relative links, such as help, search, contents, and the like.
	echo '
	<link rel="help" href="', $scripturl, '?action=help" />
	<link rel="search" href="', $scripturl, '?action=search" />
	<link rel="contents" href="', $scripturl, '" />';

	// If RSS feeds are enabled, advertise the presence of one.
	if (!empty($modSettings['xmlnews_enable']) && (!empty($modSettings['allow_guestAccess']) || $context['user']['is_logged']))
		echo '
	<link rel="alternate" type="application/rss+xml" title="', $context['forum_name_html_safe'], ' - ', $txt['rss'], '" href="', $scripturl, '?type=rss;action=.xml" />';

	// If we're viewing a topic, these should be the previous and next topics, respectively.
	if (!empty($context['current_topic']))
		echo '
	<link rel="prev" href="', $scripturl, '?topic=', $context['current_topic'], '.0;prev_next=prev" />
	<link rel="next" href="', $scripturl, '?topic=', $context['current_topic'], '.0;prev_next=next" />';

	// If we're in a board, or a topic for that matter, the index will be the board's index.
	if (!empty($context['current_board']))
		echo '
	<link rel="index" href="', $scripturl, '?board=', $context['current_board'], '.0" />';
	
	// Factory stuff
	echo'
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="', $settings['theme_url'], '/css/bootstrap.min.css" rel="stylesheet" media="screen">
		<script type="text/javascript" src="', $settings['theme_url'], '/scripts/jquery.min.js"></script>
		<script type="text/javascript" src="', $settings['theme_url'], '/scripts/bootstrap.min.js"></script>';

	// Output any remaining HTML headers. (from mods, maybe?)
	echo $context['html_headers'];

	echo '
</head>
<body>';
}

function template_body_above()
{
	global $context, $settings, $options, $scripturl, $txt, $modSettings;
	
	// Show the menu here, according to the menu sub template.
	template_menu();
	
	// Container!
	echo'
		<div class="container" style="min-height: 600px;">';
		
	// Is the forum in maintenance mode?
	if ($context['in_maintenance'] && $context['user']['is_admin'])
		echo '
				<div class="alert alert-danger"><span class="glyphicon glyphicon-warning-sign"></span> ', $txt['maintain_mode_on'], '</div>';
				
	// Show the navigation tree.
	theme_linktree();
	
	// Search it!
	echo'
		<div class="row">
			<div class="col-md-9">
				<form class="navbar-form navbar-left" role="search" id="search_form" action="', $scripturl, '?action=search2" method="post" accept-charset="', $context['character_set'], '">
				      <div class="form-group">
				        <input type="text" class="form-control" placeholder="', $txt['search'], '" name="search" />
				      </div>
				      <input type="hidden" name="advanced" value="0" />
				      <button type="submit" class="btn btn-default"><span class="glyphicon glyphicon-search"></span> ', $txt['search'], '</button> <a href="', $scripturl, '?action=search;advanced=1"><span class="glyphicon glyphicon-cog"></span></a>';
				      
			if (!empty($context['current_topic']))
				echo '
							<input type="hidden" name="topic" value="', $context['current_topic'], '" />';
			// If we're on a certain board, limit it to this board ;).
			elseif (!empty($context['current_board']))
				echo '
							<input type="hidden" name="brd[', $context['current_board'], ']" value="', $context['current_board'], '" />';
							
			echo'
						<br class="clear" /><br class="clear" />
						<span class="glyphicon glyphicon-time"></span> ', $context['current_time'];
						
			if ($context['allow_calendar'])
				echo'
					 | <span class="glyphicon glyphicon-calendar"></span> <a href="', $scripturl, '?action=calendar">', $txt['calendar'], '</a>';
					 
			echo'
				    </form>
			</div>
			<div class="col-md-3">';
			
				
	if (!empty($settings['enable_news']))
		echo '
				<h4><span class="glyphicon glyphicon-bullhorn"></span> ', $txt['news'], ': </h4>
				<p>', $context['random_news_line'], '</p>';
				
	echo'
			</div>
		</div>
		<hr />';

	// Define the upper_section toggle in JavaScript.
	echo '
		<script type="text/javascript"><!-- // --><![CDATA[
			var oMainHeaderToggle = new smc_Toggle({
				bToggleEnabled: true,
				bCurrentlyCollapsed: ', empty($options['collapse_header']) ? 'false' : 'true', ',
				aSwappableContainers: [
					\'upper_section\'
				],
				aSwapImages: [
					{
						sId: \'upshrink\',
						srcExpanded: smf_images_url + \'/upshrink.png\',
						altExpanded: ', JavaScriptEscape($txt['upshrink_description']), ',
						srcCollapsed: smf_images_url + \'/upshrink2.png\',
						altCollapsed: ', JavaScriptEscape($txt['upshrink_description']), '
					}
				],
				oThemeOptions: {
					bUseThemeSettings: ', $context['user']['is_guest'] ? 'false' : 'true', ',
					sOptionName: \'collapse_header\',
					sSessionVar: ', JavaScriptEscape($context['session_var']), ',
					sSessionId: ', JavaScriptEscape($context['session_id']), '
				},
				oCookieOptions: {
					bUseCookie: ', $context['user']['is_guest'] ? 'true' : 'false', ',
					sCookieName: \'upshrink\'
				}
			});
		// ]]></script>';
}

function template_body_below()
{
	global $context, $settings, $options, $scripturl, $txt, $modSettings;

	echo '
		</div>
		</div></div>';

	// Show the "Powered by" and "Valid" logos, as well as the copyright. Remember, the copyright must be somewhere!
	echo '
	<div id="footer_section">
		<ul class="reset">';
		
			echo'
				<li class="copyright">', theme_copyright(), '</li>';
			
		if (!empty($modSettings['seo_enable_sitemap']) && !empty($modSettings['seo_sitemap_show']) && $modSettings['seo_sitemap_show'] != 2)
			echo'
				<li><a href="', $scripturl, '?action=sitemap" title="', $txt['seo_sitemap'], '"><span>', $txt['seo_sitemap'], '</span></a></li>';

		echo'
			<li><a id="button_xhtml" href="http://validator.w3.org/check?uri=referer" target="_blank" class="new_win" title="', $txt['valid_xhtml'], '"><span>', $txt['xhtml'], '</span></a></li>
			', !empty($modSettings['xmlnews_enable']) && (!empty($modSettings['allow_guestAccess']) || $context['user']['is_logged']) ? '<li><a id="button_rss" href="' . $scripturl . '?action=.xml;type=rss" class="new_win"><span>' . $txt['rss'] . '</span></a></li>' : '', '
			<li class="last"><a id="button_wap2" href="', $scripturl , '?wap2" class="new_win"><span>', $txt['wap2'], '</span></a></li>
		</ul>';
		
		if (!empty($settings['show_sky_button']))
			echo'
				<a href="#" class="scrollup">Scroll to top</a>';

	// Show the load time?
	if ($context['show_load_time'])
		echo '
		<p>', $txt['page_created'], $context['load_time'], $txt['seconds_with'], $context['load_queries'], $txt['queries'], '</p>';

	echo '
		</div>';
}

function template_html_below()
{
	global $context, $settings, $options, $scripturl, $txt, $modSettings;
	
	// Factory stuff
	echo'
		<script>
			$(".button").attr("class", "btn btn-default");
			$(".button_submit").attr("class", "btn btn-info");
			$(".table_grid").attr("class", "table table-striped");
			$(".description").attr("class", "alert alert-info");
			$(".plainbox").attr("class", "alert alert-success");
			$("img.new_posts").replaceWith(\'<span class="label label-warning">' . $txt['new'] . '</span>\');
			$(".shd_ticketlist").attr("class", "table table-striped");
			$(".bordercolor").attr("class", "table table-striped");';
			
	if (!empty($settings['show_sky_button']))
		echo'
			$(document).ready(function(){ 
		        $(window).scroll(function(){
		            if ($(this).scrollTop() > 100) {
		                $(\'.scrollup\').fadeIn();
		            } else {
		                $(\'.scrollup\').fadeOut();
		            }
		        }); 
		        $(\'.scrollup\').click(function(){
		            $("html, body").animate({ scrollTop: 0 }, 600);
		            return false;
		        });
		    });';
		    
	echo'
		</script>';

	echo '
</body></html>';
}

// Show a linktree. This is that thing that shows "My Community | General Category | General Discussion"..
function theme_linktree($force_show = false)
{
	global $context, $settings, $options, $shown_linktree;

	// If linktree is empty, just return - also allow an override.
	if (empty($context['linktree']) || (!empty($context['dont_default_linktree']) && !$force_show))
		return;

	echo '
		<ol class="breadcrumb">';

	// Each tree item has a URL and name. Some may have extra_before and extra_after.
	foreach ($context['linktree'] as $link_num => $tree)
	{
		echo '
			<li', ($link_num == count($context['linktree']) - 1) ? ' class="last"' : '', ' itemscope="itemscope" itemtype="http://data-vocabulary.org/Breadcrumb">';

		// Show the link, including a URL if it should have one.
		echo $settings['linktree_link'] && isset($tree['url']) ? '
				<a href="' . $tree['url'] . '" itemprop="url"><span itemprop="name">' . $tree['name'] . '</span></a>' : '<span itemprop="name">' . $tree['name'] . '</span>';

		echo '
			</li>';
	}
	echo '
		</ol>';

	$shown_linktree = true;
}

// Show the menu up top. Something like [home] [help] [profile] [logout]...
function template_menu()
{
	global $context, $settings, $options, $scripturl, $txt;

	echo '
		<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
		  <!-- Brand and toggle get grouped for better mobile display -->
		  <div class="container">
			  <div class="navbar-header">
			    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
			      <span class="sr-only">Toggle navigation</span>
			      <span class="icon-bar"></span>
			      <span class="icon-bar"></span>
			      <span class="icon-bar"></span>
			    </button>
			    <a class="navbar-brand" href="', $scripturl, '">', empty($context['header_logo_url_html_safe']) ? $context['forum_name'] : '<img src="' . $context['header_logo_url_html_safe'] . '" alt="' . $context['forum_name'] . '" />', '</a>
			  </div>
			
			  <!-- Collect the nav links, forms, and other content for toggling -->
			  <div class="collapse navbar-collapse navbar-ex1-collapse">
			    <ul class="nav navbar-nav">';
			
		$prevent_actions = array('logout', 'login', 'register', 'profile', 'admin', 'moderate', 'search', 'help', 'calendar');
		
		if (count($context['menu_buttons']) < 17)
			$prevent_actions[] = 'pm';
		
		foreach ($context['menu_buttons'] as $act => $button)
		{
			if (in_array($act, $prevent_actions))
				continue;
			
			if (empty($button['sub_buttons']))
				echo '
						<li id="button_', $act, '"', $button['active_button'] ? ' class="active" ' : '', '>
							<a href="', $button['href'], '"', isset($button['target']) ? ' target="' . $button['target'] . '"' : '', ' ', isset($button['nofollow']) ? ' rel="nofollow"' : '', '>
								<span>', $button['title'], '</span>
							</a>';
			else
				echo '
						<li id="button_', $act, '" class="dropdown', $button['active_button'] ? ' active ' : '', '">
							<a href="', $button['href'], '"', isset($button['target']) ? ' target="' . $button['target'] . '"' : '', ' ', isset($button['nofollow']) ? ' rel="nofollow"' : '', ' class="dropdown-toggle" data-toggle="dropdown">
								<span>', $button['title'], ' <b class="caret"></b></span>
							</a>';
							
							
			if (!empty($button['sub_buttons']))
			{
				echo '
						<ul class="dropdown-menu">
							<li>
								<a href="', $button['href'], '"', isset($button['target']) ? ' target="' . $button['target'] . '"' : '', ' ', isset($button['nofollow']) ? ' rel="nofollow"' : '', '>
									<span>', $button['title'], '</span>
								</a>
							</li>';
	
				foreach ($button['sub_buttons'] as $childbutton)
				{
					echo '
							<li>
								<a href="', $childbutton['href'], '"', isset($childbutton['target']) ? ' target="' . $childbutton['target'] . '"' : '', '>
									<span', isset($childbutton['is_last']) ? ' class="last"' : '', '>', $childbutton['title'], !empty($childbutton['sub_buttons']) ? '...' : '', '</span>
								</a>
							</li>';
				}
					echo '
						</ul>';
			}
			echo '
					</li>';
		}
			      
			      
		echo'
			    </ul>
			    <ul class="nav navbar-nav navbar-right">
			      <li class="dropdown">';
			      
		// If the user is logged in, display stuff like their name, new messages, etc.
		if ($context['user']['is_logged'])
		{
			echo'
				<a href="#" class="dropdown-toggle" data-toggle="dropdown">', $txt['hello_member_ndt'], '&nbsp;', (allowedTo('pm_read') && $context['user']['unread_messages'] > 0 ? ' [' . $context['user']['unread_messages'] . ']' : '');
			
			if (!empty($context['user']['avatar']))
				echo'
					<img src="', $context['user']['avatar']['href'], '" style="max-width: 16px; max-height: 16px;" alt="" /> ';
			
			echo $context['user']['name'], ' <b class="caret"></b></a>
				<ul class="dropdown-menu">
					<li><a href="', $scripturl, '?action=profile">', $txt['profile'], '</a></li>';
			
			if ($context['user']['is_admin'])
				echo'
					<li><a href="', $scripturl, '?action=admin">', $txt['admin'], '</a></li>';
					
			if ($context['user']['is_mod'])
				echo'
					<li><a href="', $scripturl, '?action=moderate">', $txt['moderate'], '</a></li>';
			
			if (allowedTo('pm_read'))
				echo '
					<li><a href="', $scripturl, '?action=pm">', $txt['personal_messages'], '</a></li>';
					
			echo'
					<li><a href="', $scripturl, '?action=unread">', $txt['unread_since_visit'], '</a></li>
					<li><a href="', $scripturl, '?action=unreadreplies">', $txt['show_unread_replies'], '</a></li>';
	
			// Are there any members waiting for approval?
			if (!empty($context['unapproved_members']))
				echo '
						<li><a href="', $scripturl, '?action=admin;area=viewmembers;sa=browse;type=approve">', $context['unapproved_members'] == 1 ? $txt['approve_thereis'] : $txt['approve_thereare'], ' ', $context['unapproved_members'] == 1 ? $txt['approve_member'] : $context['unapproved_members'] . ' ' . $txt['approve_members'], ' ', $txt['approve_members_waiting'], '</a></li>';
	
			if (!empty($context['open_mod_reports']) && $context['show_open_reports'])
				echo '
						<li><a href="', $scripturl, '?action=moderate;area=reports">', sprintf($txt['mod_reports_waiting'], $context['open_mod_reports']), '</a></li>';
	
			echo '
						<li><a href="', $scripturl, '?action=logout;', $context['session_var'], '=', $context['session_id'], '">', $txt['logout'], '</a></li>';
		}
		// Otherwise they're a guest - this time ask them to either register or login - lazy bums...
		elseif (!empty($context['show_login_bar']))
		{
			echo '
					<script type="text/javascript" src="', $settings['default_theme_url'], '/scripts/sha1.js"></script>
					<li><a href="', $scripturl, '?action=register">', $txt['register'], '</a></li>
			        <li class="divider-vertical"></li>
			        <li class="dropdown">
			        	<a class="dropdown-toggle" href="#" data-toggle="dropdown">', $txt['login'], ' <strong class="caret"></strong></a>
			        	<div class="dropdown-menu" style="padding: 15px; padding-bottom: 0px; min-width: 300px; min-height: 200px;">
							<form id="guest_form" action="', $scripturl, '?action=login2" method="post" accept-charset="', $context['character_set'], '" ', empty($context['disable_login_hashing']) ? ' onsubmit="hashLoginPassword(this, \'' . $context['session_id'] . '\');"' : '', '>
								<div>
									<input type="text" name="user" size="30" style="margin-bottom: 15px;" placeholder="', $txt['user'], '" />
								</div><div>
									<input type="password" name="passwrd" size="30" style="margin-bottom: 15px;" placeholder="', $txt['password'], '" />
								</div><div>
									<select name="cookielength">
										<option value="60">', $txt['one_hour'], '</option>
										<option value="1440">', $txt['one_day'], '</option>
										<option value="10080">', $txt['one_week'], '</option>
										<option value="43200">', $txt['one_month'], '</option>
										<option value="-1" selected="selected">', $txt['forever'], '</option>
									</select>
								</div>
								<br class="clear" />
								<input type="submit" value="', $txt['login'], '" class="btn btn-info" /><br />';
			
					if (!empty($modSettings['enableOpenID']))
						echo '
								<br /><input type="text" name="openid_identifier" id="openid_url" size="25" class="input_text openid_login" />';
			
					echo '
								<input type="hidden" name="hash_passwrd" value="" />
							</form>
						</div>';
		}
		
		echo'
			      </li>
			    </ul>
			  </div><!-- /.navbar-collapse -->
		   </div>
		</nav>';
}

// Generate a strip of buttons.
function template_button_strip($button_strip, $direction = 'top', $strip_options = array())
{
	global $settings, $context, $txt, $scripturl;

	if (!is_array($strip_options))
		$strip_options = array();

	// List the buttons in reverse order for RTL languages.
	if ($context['right_to_left'])
		$button_strip = array_reverse($button_strip, true);

	// Create the buttons...
	$buttons = array();
	foreach ($button_strip as $key => $value)
	{
		if (!isset($value['test']) || !empty($context[$value['test']]))
			$buttons[] = '
				<li' . (isset($value['active']) ? ' class="active"' : '') . '><a' . (isset($value['id']) ? ' id="button_strip_' . $value['id'] . '"' : '') . ' class="button_strip_' . $key . '" href="' . $value['url'] . '"' . (isset($value['custom']) ? ' ' . $value['custom'] : '') . '><span>' . $txt[$value['text']] . '</span></a></li>';
	}

	// No buttons? No button strip either.
	if (empty($buttons))
		return;

	// Make the last one, as easy as possible.
	$buttons[count($buttons) - 1] = str_replace('<span>', '<span class="last">', $buttons[count($buttons) - 1]);

	echo '
		<div class="', !empty($direction) ? ' float' . $direction : '', '"', (empty($buttons) ? ' style="display: none;"' : ''), (!empty($strip_options['id']) ? ' id="' . $strip_options['id'] . '"': ''), '>
			<ul class="nav nav-pills">',
				implode('', $buttons), '
			</ul>
		</div>';
}

?>